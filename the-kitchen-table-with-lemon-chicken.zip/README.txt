MY RECIPE BOOK — FREE WEBSITE

This is a static recipe website designed to run free on GitHub Pages.

FILES
- index.html — main recipe site
- styles.css — design and mobile layout
- script.js — mobile menu, recipe search, and category filtering

PUBLISH FOR FREE WITH GITHUB PAGES
1. Create a free account at https://github.com
2. Create a new public repository, for example: my-recipes
3. Upload index.html, styles.css, and script.js
4. Open Settings > Pages
5. Under Build and deployment, choose "Deploy from a branch"
6. Select the main branch and /root folder
7. GitHub will give you a free address similar to:
   https://YOUR-USERNAME.github.io/my-recipes/

HOW TO ADD RECIPES
Duplicate one of the recipe-card sections in index.html and add a matching recipe-detail section below it. Update the title, category, ingredients, directions, and timing.

You can replace the site title "My Recipe Book" with your own cookbook or family name.
